// requestLogger = require('../../src/utilities/RequestLogger')

// describe("RequestLogger ", function () {
//     it("should validate the incoming emailId", function (done) {
//         expect(Validator.validateEmail("sree@gmail.com")).toBeTruthy();
//     });
// });
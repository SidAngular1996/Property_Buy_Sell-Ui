class user{
    constructor(obj){
       this.userId=obj.userId
        this.name=obj.name
        this.emailId= obj.emailId
        this.contactNo=obj.contactNo
        this.city=obj.city
        this.area= obj.area
        this.pincode= obj.pincode
        this.password= obj.password
        this.wishlist=obj.wishlist;

    }
}
module.exports=user